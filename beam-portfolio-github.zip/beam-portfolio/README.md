# Beam Monsicha — Portfolio Website

A responsive multi-page personal portfolio website with a soft pink, modern and friendly style.

## Pages
- `index.html` — Home
- `about.html` — About, skills and introduction
- `projects.html` — Projects and achievements
- `experience.html` — Work experience
- `contact.html` — Contact information

## Before publishing
1. Replace the `BM` photo placeholders with your own photo if desired.
2. Replace placeholder contact information in `contact.html` and in the header of `index.html`.
3. Update project descriptions, actual roles, and tools used to match your real work.
4. Check that every listed skill is a tool or technology you have actually used.
5. Add real project screenshots to `assets/img/` and link them in the project pages if available.

## Publish with GitHub Pages
1. Create a new public repository on GitHub, e.g. `beam-portfolio`.
2. Upload all files and folders in this project (upload the contents, not just the ZIP file).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL will usually look like `https://YOUR-USERNAME.github.io/beam-portfolio/`.

The website is static HTML/CSS/JavaScript and does not require a build step. Google Fonts are loaded online; the rest of the site is self-contained.
